<template>
    <TopNav class="w-full"/>
    <div class="sm:hidden px-[5px] pt-[100px] mx-auto">
        <Search />
    </div>
    <div class="border-t md:pt-[100px] mt-5 w-full flex justify-center">
        <weather/>   
    </div>
    <div class="border-t">
        <SiteMenu/>
    </div>
</template>

<script setup>

</script>