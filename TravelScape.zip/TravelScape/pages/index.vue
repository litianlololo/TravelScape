<template>
    
    <MainLayout/>
    <comments/>
</template>

<script setup>
import MainLayout from '../layouts/MainLayout.vue';

</script>