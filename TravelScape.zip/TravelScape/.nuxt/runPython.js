const { PythonShell } = require('python-shell');
const path = require('path');

// 定义 Python 脚本文件的路径（相对于项目根目录）
const pythonScriptPath = path.join(__dirname, 'main.py');

async function runPythonScript() {
  const options = {
    mode: 'text',
    pythonPath: '/usr/bin/python', // 根据你的 Python 安装路径配置
    pythonOptions: ['-u'], // 使输出以流的形式传递
    scriptPath: __dirname, // 当前文件的目录
    args: [], // 传递给 Python 脚本的参数（如果需要的话）
  };

  return new Promise((resolve, reject) => {
    PythonShell.run(pythonScriptPath, options, (err, results) => {
      if (err) {
        console.error('Python 脚本执行出错：', err);
        reject(err);
      } else {
        console.log('Python 脚本执行成功！');
        resolve(results);
      }
    });
  });
}

module.exports = { runPythonScript };